# Twitter Clone

A Twitter clone with a machine learning based recommendation system.

*React.js, Node.js, Firebase, Hugging Face, Flexbox*

**Showcase**

https://github.com/mehdiimam439/twitter-clone/assets/60456257/55270078-31b5-477c-b337-a8408290e61b

**Signing up**

![signup](https://github.com/mehdiimam439/twitter-clone/assets/60456257/f425b0c7-1fe2-472d-a128-c20da1da93a4)

**Signing in**

![login](https://github.com/mehdiimam439/twitter-clone/assets/60456257/eccd525b-1a78-4c51-94fa-9f02ced46f14)

**Exploring tweets**

![explore](https://github.com/mehdiimam439/twitter-clone/assets/60456257/3c635a0d-5415-4124-83e1-ae7f75715e36)

**Showing relevant tweets with Machine Learning**

![relevant-tweets](https://github.com/mehdiimam439/twitter-clone/assets/60456257/07e35831-4c35-4dc8-b602-ef293443c51a)

**Dark mode**

![dark-mode](https://github.com/mehdiimam439/twitter-clone/assets/60456257/e0113d72-1b0e-4c61-8baa-9f7ce64f8a8a)
